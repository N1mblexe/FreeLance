public class HighScore {
    int score;
    String name;

    public HighScore(int score , String name)
    {
        this.score = score;
        this.name = name;
    }
}
