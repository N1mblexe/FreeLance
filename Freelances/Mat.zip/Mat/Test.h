#pragma once
#include "Matrix.h"
#include <iostream>

class Test
{
public:
	void Run();
private:
	void GenerateRandomMatrix(Matrix& mat);
};