#include "Test.h"

int main()
{
	Test* t = new Test();

	t->Run();

	return 0;
}