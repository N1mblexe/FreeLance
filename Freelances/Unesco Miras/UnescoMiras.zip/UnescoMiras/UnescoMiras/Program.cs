﻿using System;
using System.Collections.Generic;
using UnescoMiras;

internal class Program
{
    static void Main(string[] args)
    {
        UM.StackX<UM_Alani>[] stack = new UM.StackX<UM_Alani>[7];
        UM.QueueX<UM_Alani>[] queue = new UM.QueueX<UM_Alani>[7];

        stack = UM_Alani.ReadDataFromFile("data.txt");
        queue = UM_Alani.ReadDataFromFileQueue("data.txt");

        Console.WriteLine("STACK (YIĞIT):");
        PrintDatas(stack);
        Console.WriteLine("########################################################");

        Console.WriteLine("QUEUE (YIĞIN):");
        PrintDatas(queue);
        Console.WriteLine("########################################################");
    
    }

    static void PrintDatas(UM.StackX<UM_Alani>[] stacks)
    {
        for (int i = 0; i < stacks.Length; i++)
        {
            Console.WriteLine($"Stack {i + 1}:");

            try
            {
                while (stacks[i].Peek() != null)
                {
                    stacks[i].Pop()?.Print();
                }
            }
            catch (InvalidOperationException ignored){ }

            Console.WriteLine();
        }
    }

    static void PrintDatas(UM.QueueX<UM_Alani>[] queues)
    {
        for (int i = 0; i < queues.Length; i++)
        {
            Console.WriteLine($"Queue {i + 1}:");

            try
            {
                while (queues[i].Peek() != null)
                {
                    queues[i].Dequeue()?.Print();
                }
            }
            catch (InvalidOperationException ignored) { }

            Console.WriteLine();
        }
    }





}
