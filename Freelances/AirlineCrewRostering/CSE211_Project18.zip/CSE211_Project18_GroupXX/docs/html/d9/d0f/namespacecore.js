var namespacecore =
[
    [ "FileParser", "da/d96/classcore_1_1FileParser.html", null ],
    [ "RosterEngine", "dc/d1c/classcore_1_1RosterEngine.html", "dc/d1c/classcore_1_1RosterEngine" ],
    [ "Validator", "d9/d5f/classcore_1_1Validator.html", null ]
];