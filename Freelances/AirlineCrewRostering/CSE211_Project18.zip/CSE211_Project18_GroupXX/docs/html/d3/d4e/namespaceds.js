var namespaceds =
[
    [ "Vertex", "df/d38/structds_1_1Vertex.html", "df/d38/structds_1_1Vertex" ],
    [ "Edge", "d8/ded/structds_1_1Edge.html", "d8/ded/structds_1_1Edge" ],
    [ "Graph", "da/dd0/classds_1_1Graph.html", "da/dd0/classds_1_1Graph" ],
    [ "Entry", "da/da3/structds_1_1Entry.html", "da/da3/structds_1_1Entry" ],
    [ "HashMap", "d0/d9b/classds_1_1HashMap.html", "d0/d9b/classds_1_1HashMap" ],
    [ "ListNode", "d3/d98/structds_1_1ListNode.html", "d3/d98/structds_1_1ListNode" ],
    [ "LinkedList", "dc/d5d/classds_1_1LinkedList.html", "dc/d5d/classds_1_1LinkedList" ],
    [ "HeapNode", "db/dc9/structds_1_1HeapNode.html", "db/dc9/structds_1_1HeapNode" ],
    [ "PriorityQueue", "db/d16/classds_1_1PriorityQueue.html", "db/d16/classds_1_1PriorityQueue" ],
    [ "deleteSubtree", "d3/d4e/namespaceds.html#a9b995c865d45466cd64be9ceaf4634f6", null ]
];