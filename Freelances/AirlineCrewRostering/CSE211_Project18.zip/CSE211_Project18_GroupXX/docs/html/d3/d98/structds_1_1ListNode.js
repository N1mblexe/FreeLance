var structds_1_1ListNode =
[
    [ "ListNode", "d3/d98/structds_1_1ListNode.html#a60515156cdf2188644755384499f75a6", null ],
    [ "data", "d3/d98/structds_1_1ListNode.html#abf4ec908188f53746441617a6134daed", null ],
    [ "next", "d3/d98/structds_1_1ListNode.html#a8339383ef73386f9f4ff416ce56e8ed2", null ],
    [ "prev", "d3/d98/structds_1_1ListNode.html#a23cea96c043a1b1fa483267fb23587d5", null ]
];