var structds_1_1Edge =
[
    [ "operator==", "d8/ded/structds_1_1Edge.html#a0872058790fd11649a404122440f44ee", null ],
    [ "durationMinutes", "d8/ded/structds_1_1Edge.html#a78e8b6c857dbbc5668c63849a4409403", null ],
    [ "flightId", "d8/ded/structds_1_1Edge.html#a68aa0afe5528f76b9164b76d59009a8c", null ],
    [ "toVertex", "d8/ded/structds_1_1Edge.html#a9e182c33c5a8bb39102074c816c60ceb", null ]
];