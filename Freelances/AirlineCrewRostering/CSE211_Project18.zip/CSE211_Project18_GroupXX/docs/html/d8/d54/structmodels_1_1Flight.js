var structmodels_1_1Flight =
[
    [ "Flight", "d8/d54/structmodels_1_1Flight.html#acbf1e8c321e01e04db2fe651a08b30af", null ],
    [ "Flight", "d8/d54/structmodels_1_1Flight.html#a692fc56e3e91c5459055a5a28a8b6932", null ],
    [ "getDuration", "d8/d54/structmodels_1_1Flight.html#a58330ae7f875e3d6a202d0b36ad0ab11", null ],
    [ "operator==", "d8/d54/structmodels_1_1Flight.html#ac6cecab19ab5e8d355012b8d6f4be1ae", null ],
    [ "aircraftType", "d8/d54/structmodels_1_1Flight.html#af40f9a92e492af3917317747c7585851", null ],
    [ "arrivalTime", "d8/d54/structmodels_1_1Flight.html#a53841092622c4146c94f5f62a827180d", null ],
    [ "departureTime", "d8/d54/structmodels_1_1Flight.html#a2017eeb1e7345c7533d64c59efe27112", null ],
    [ "destination", "d8/d54/structmodels_1_1Flight.html#ab684a194b75e89ac7820e9901494f664", null ],
    [ "id", "d8/d54/structmodels_1_1Flight.html#af88cf6391f66eaee21b0298ab7240eae", null ],
    [ "origin", "d8/d54/structmodels_1_1Flight.html#ad3c6d3dd2d6b4b7ec0c3b2609af83cb7", null ]
];