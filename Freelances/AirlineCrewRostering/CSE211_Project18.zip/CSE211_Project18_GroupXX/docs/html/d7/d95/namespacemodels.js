var namespacemodels =
[
    [ "Crew", "da/db2/classmodels_1_1Crew.html", "da/db2/classmodels_1_1Crew" ],
    [ "Flight", "d8/d54/structmodels_1_1Flight.html", "d8/d54/structmodels_1_1Flight" ],
    [ "Pairing", "d9/d47/classmodels_1_1Pairing.html", "d9/d47/classmodels_1_1Pairing" ],
    [ "CrewRole", "d7/d95/namespacemodels.html#a64b80af33a97b34cc4db1b1091abe89c", [
      [ "PILOT", "d7/d95/namespacemodels.html#a64b80af33a97b34cc4db1b1091abe89caece6117f0bc60ec824fe5d441abdb288", null ],
      [ "ATTENDANT", "d7/d95/namespacemodels.html#a64b80af33a97b34cc4db1b1091abe89cae36f6c331626994639cba912deb4195f", null ]
    ] ]
];