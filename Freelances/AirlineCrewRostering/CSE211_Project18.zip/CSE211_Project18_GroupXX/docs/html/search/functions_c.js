var searchData=
[
  ['vertex_0',['Vertex',['../df/d38/structds_1_1Vertex.html#a2ee3a7ffe6b3bdeea0a4b4c7a99004af',1,'ds::Vertex']]]
];
