var searchData=
[
  ['validator_0',['Validator',['../d9/d5f/classcore_1_1Validator.html',1,'core']]],
  ['vertex_1',['Vertex',['../df/d38/structds_1_1Vertex.html',1,'ds']]]
];
