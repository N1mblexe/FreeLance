var searchData=
[
  ['rosterengine_0',['RosterEngine',['../dc/d1c/classcore_1_1RosterEngine.html',1,'core']]]
];
