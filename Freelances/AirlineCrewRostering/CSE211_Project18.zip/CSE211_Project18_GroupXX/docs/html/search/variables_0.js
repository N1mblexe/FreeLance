var searchData=
[
  ['aircrafttype_0',['aircraftType',['../d8/d54/structmodels_1_1Flight.html#af40f9a92e492af3917317747c7585851',1,'models::Flight']]],
  ['arrivaltime_1',['arrivalTime',['../d8/d54/structmodels_1_1Flight.html#a53841092622c4146c94f5f62a827180d',1,'models::Flight']]]
];
