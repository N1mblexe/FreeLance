var searchData=
[
  ['rosterengine_0',['RosterEngine',['../dc/d1c/classcore_1_1RosterEngine.html#a8765076f59c1961011f8bf7675d120d3',1,'core::RosterEngine']]]
];
