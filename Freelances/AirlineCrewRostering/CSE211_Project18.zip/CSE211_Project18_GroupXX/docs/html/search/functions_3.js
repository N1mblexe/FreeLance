var searchData=
[
  ['flight_0',['Flight',['../d8/d54/structmodels_1_1Flight.html#acbf1e8c321e01e04db2fe651a08b30af',1,'models::Flight::Flight()'],['../d8/d54/structmodels_1_1Flight.html#a692fc56e3e91c5459055a5a28a8b6932',1,'models::Flight::Flight(std::string fId, std::string from, std::string to, int dept, int arr, std::string type)']]]
];
