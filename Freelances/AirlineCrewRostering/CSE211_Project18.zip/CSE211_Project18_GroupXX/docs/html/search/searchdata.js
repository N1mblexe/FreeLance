var indexSectionsWithContent =
{
  0: "acdefghiklmnoprtv~",
  1: "cefghlprv",
  2: "cdmt",
  3: "cfghlmprtv",
  4: "acdfghilmoprv~",
  5: "adefiklnoprtv",
  6: "c",
  7: "ap"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator"
};

