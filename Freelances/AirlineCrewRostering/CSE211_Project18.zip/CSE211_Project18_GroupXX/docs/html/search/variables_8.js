var searchData=
[
  ['origin_0',['origin',['../d8/d54/structmodels_1_1Flight.html#ad3c6d3dd2d6b4b7ec0c3b2609af83cb7',1,'models::Flight']]]
];
