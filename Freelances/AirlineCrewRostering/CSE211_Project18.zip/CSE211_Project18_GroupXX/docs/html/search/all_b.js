var searchData=
[
  ['name_0',['name',['../df/d38/structds_1_1Vertex.html#a035061b667ff7f89ce858b6450d4e7d9',1,'ds::Vertex']]],
  ['next_1',['next',['../d3/d98/structds_1_1ListNode.html#a8339383ef73386f9f4ff416ce56e8ed2',1,'ds::ListNode']]]
];
