var searchData=
[
  ['deletesubtree_0',['deleteSubtree',['../d3/d4e/namespaceds.html#a9b995c865d45466cd64be9ceaf4634f6',1,'ds']]]
];
