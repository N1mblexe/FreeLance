var annotated_dup =
[
    [ "core", "d9/d0f/namespacecore.html", [
      [ "FileParser", "da/d96/classcore_1_1FileParser.html", null ],
      [ "RosterEngine", "dc/d1c/classcore_1_1RosterEngine.html", "dc/d1c/classcore_1_1RosterEngine" ],
      [ "Validator", "d9/d5f/classcore_1_1Validator.html", null ]
    ] ],
    [ "ds", "d3/d4e/namespaceds.html", [
      [ "Vertex", "df/d38/structds_1_1Vertex.html", "df/d38/structds_1_1Vertex" ],
      [ "Edge", "d8/ded/structds_1_1Edge.html", "d8/ded/structds_1_1Edge" ],
      [ "Graph", "da/dd0/classds_1_1Graph.html", "da/dd0/classds_1_1Graph" ],
      [ "Entry", "da/da3/structds_1_1Entry.html", "da/da3/structds_1_1Entry" ],
      [ "HashMap", "d0/d9b/classds_1_1HashMap.html", "d0/d9b/classds_1_1HashMap" ],
      [ "ListNode", "d3/d98/structds_1_1ListNode.html", "d3/d98/structds_1_1ListNode" ],
      [ "LinkedList", "dc/d5d/classds_1_1LinkedList.html", "dc/d5d/classds_1_1LinkedList" ],
      [ "HeapNode", "db/dc9/structds_1_1HeapNode.html", "db/dc9/structds_1_1HeapNode" ],
      [ "PriorityQueue", "db/d16/classds_1_1PriorityQueue.html", "db/d16/classds_1_1PriorityQueue" ]
    ] ],
    [ "models", "d7/d95/namespacemodels.html", [
      [ "Crew", "da/db2/classmodels_1_1Crew.html", "da/db2/classmodels_1_1Crew" ],
      [ "Flight", "d8/d54/structmodels_1_1Flight.html", "d8/d54/structmodels_1_1Flight" ],
      [ "Pairing", "d9/d47/classmodels_1_1Pairing.html", "d9/d47/classmodels_1_1Pairing" ]
    ] ]
];