var RosterEngine_8hpp =
[
    [ "core::RosterEngine", "dc/d1c/classcore_1_1RosterEngine.html", "dc/d1c/classcore_1_1RosterEngine" ]
];