#include "Application.h"

#define FILE_NAME "file.txt"

int main() 
{
    Application app(FILE_NAME);

    app.Run();
}