#include "Randevu.h"

Randevu::Randevu(){}

Randevu::Randevu(std::string tarih)
{
	this->tarih = tarih;
}
