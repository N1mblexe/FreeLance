#include "Hemsire.h"

std::string Hemsire::HemsireBilgileri()
{
	return ("Ad: " + ad + "\tSoyad: " + soyad + "\tid: " + std::to_string(id));
}