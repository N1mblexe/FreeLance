#pragma once

#include <string>

class Randevu
{
public:
	std::string tarih;

	Randevu();
	Randevu(std::string tarih);
};