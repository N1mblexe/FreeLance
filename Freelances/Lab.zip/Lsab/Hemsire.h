#pragma once

#include <string>

class Hemsire
{
public:
	std::string ad;
	std::string soyad;

	int id;

	std::string HemsireBilgileri();

private:
};