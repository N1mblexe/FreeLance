#include "Lab.h"

int main() {
    Lab lab; 

    lab.Calistir();

    return 0;
}
