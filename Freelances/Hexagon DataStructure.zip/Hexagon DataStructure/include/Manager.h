#ifndef MANAGER_H
#define MANAGER_H

#include "Hexagon.h"

class Manager
{
public:
    Manager();
    ~Manager();
    void readDataFile(const char *filename);
    void runSimulation(int turns);
    void visualize(bool showDetails = false) const;

private:
    Hexagon **hexagons;
    int hexagonCount;
};

#endif // MANAGER_H
